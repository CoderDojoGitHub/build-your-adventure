game.addEventListener("load", function(){

  // Character code here

})
