game.addEventListener("load", function(){

  // Enemy code here

})
