game.addEventListener("load", function(){

  // Object code here

})
